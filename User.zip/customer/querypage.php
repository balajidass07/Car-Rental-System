<?php
    session_start();
    // Check if the user is logged in, if not then redirect him to login page
        if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
        header("location: login.php");
        exit;}
?>
<!DOCTYPE html>
<html>
<head>
<title>Table with database</title>
<style>
body{
background-color:#E6E6FA;
color: white;
font-family: monospace;
font-size: 25px;
}
table {
border-collapse: collapse;
width: 100%;
color: #588c7e;
font-family: monospace;
font-size: 25px;
text-align: left;
}
#button3 {
  display: inline-block;
  border-radius: 10px;
  background-color:#4CAF50;
  border: none;
  color: #000000;
  text-align: center;
  font-family: "Arial Black", Gadget, sans-serif;
  font-size: 20px;
  padding: 5px;
  width: 100px;
  transition: all 0.5s;
  cursor: pointer;
}



#button3:hover {
  background-color:#7CD0EE;
  color:white;
}

th {
background-color: #588c7e;
color: white;
}
tr:nth-child(even) {background-color: #f2f2f2}
</style>
</head>
<body>
<table>
<tr>
<th>NO</th>
<th>Queries</th>
<th>Answers</th>
</tr>
<?php
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$db = "dbdb";
$conn = new mysqli($dbhost, $dbuser, $dbpass,$db);

$cu = $_SESSION["id"];

$sq = "SELECT cust_query,reply_admin FROM query WHERE cust_ref_id like '$cu'";
$result = $conn->query($sq);
$sno=1;
if ($result->num_rows > 0) {

while($row = $result->fetch_assoc()) {

echo "<tr><td>" . $sno. "</td><td>" . $row["cust_query"]. "</td><td>" . $row["reply_admin"] . "</td></tr>";
$sno=$sno+1;
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>
</table>
<br><br>
<button id="button3" onclick="window.location.href='query.php';" style="vertical-align:middle"><span>Back</span></button>
<button id="button3" onclick="window.location.href='homepage.php';" style="vertical-align:middle"><span>Home</span></button>

<p style="background-color:#588c7e;">Please Wait.Admin typically replies within 2 days.Thanks for your patience!!</p>
</body>
</html>