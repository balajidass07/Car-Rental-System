<?php
    session_start();
    // Check if the user is logged in, if not then redirect him to login page
        if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
        header("location: login.php");
        exit;}
?>

<!DOCTYPE html>
<html>
<head>
<style>
#heading{
	padding-left: 20px;
	padding-right: 20px;
 	border-radius: 10px;
  	background-color: #000000;
  	border: none;
 	color: #F08080;
	margin-left:740px;
	width:250px;
	font-family: "Arial Black", Gadget, sans-serif;
  	text-align: center;
  	font-size: 30px;
 
}

#heading:hover{
	color: #FF6347;
	font-size: 32px;
}

body{
  background-image: url("images/query.jpg");
  background-repeat: no-repeat;
  background-size:cover;
}

textarea{
margin-top:50px;
margin-left:760px;
background-color:#E6E6FA;
border: 6px solid #ccccff;
}


#shoot {
  display: inline-block;
  border-radius: 40px;
  background-color: #ffff00;
  border: none;
  color: #000000;
  text-align: center;
  font-family: "Arial Black", Gadget, sans-serif;
  font-size: 20px;
  padding: 10px;
  width: 100px;
  transition: all 0.5s;
  cursor: pointer;
  margin-top: 5px;
  margin-left:1060px;
}



#shoot:hover {
  background-color:#4CAF50;
  color:white;
}

#button2 {
  display: inline-block;
  border-radius: 10px;
  background-color: #7CD0EE;
  border: none;
  color: #000000;
  text-align: center;
  font-family: "Arial Black", Gadget, sans-serif;
  font-size: 20px;
  padding: 5px;
  width: 100px;
  transition: all 0.5s;
  cursor: pointer;
  margin-top: 5px;
  margin-left:910px;
}



#button2:hover {
  background-color:#4CAF50;
  color:white;
}

#button3 {
  display: inline-block;
  border-radius: 10px;
  background-color: #000000;
  border: none;
  color: #ffffff;
  text-align: center;
  font-family: "Arial Black", Gadget, sans-serif;
  font-size: 25px;
  padding: 5px;
  width: 100px;
  transition: all 0.5s;
  cursor: pointer;
  margin-top: -19px;
  margin-left:0px;
}



#button3:hover {
  background-color:#4CAF50;
  color:white;
}


#click{
font-family: "Arial Black", Gadget, sans-serif;
font-size: 20px;
color:#EA266D;
margin-left:780px;
}


</style>

<!--Database Connection-->
  <?php
    include 'db_connection.php';
    ?>


</head>

<body>

<button id="button3" onclick="window.location.href='homepage.php';" style="vertical-align:middle"><span>Home</span></button>


<button id="heading" style="vertical-align:middle"><span>Shoot your Queries!!</span></button>

<form method="post" target="_self">

  <textarea name="fed" rows="10" cols="50">Type your comments here...</textarea>

  <input id="shoot" type="submit" name="go" class="button1" value="Shoot">

</form>

<p id="click">Click here to view your queries!!</p>

<button id="button2" onclick="window.location.href='querypage.php';" style="vertical-align:middle"><span>Click Me!! </span></button>



<!--INSERT IN Query-->
    <?php
      $conn = OpenCon();
    if(isset($_POST['go'])){
      $sql = "INSERT INTO query VALUES(?,?,?,?)";

      $var1 = $_POST['fed'];

      $re = "Not yet answered";

      $cu = $_SESSION["id"];
      
      //Query_id
      $q_id = null;
      $row = $conn->query("SELECT Query_id FROM query ORDER BY Query_id DESC LIMIT 1; ");
      while ($X = mysqli_fetch_assoc($row)){
        $q_id = $X['Query_id'];
      }
      if($q_id == null){
        $q_id ='Q01';
      }
      else{
      $qid_num = (int) filter_var($q_id, FILTER_SANITIZE_NUMBER_INT);
      $qid_num = $qid_num+1;
      if($qid_num<10){
      $q_id = 'Q0'.$qid_num;
      }
      else{
        $q_id = 'Q'.$qid_num;
      }}

      $stmt = mysqli_prepare($conn,$sql);
      $stmt->bind_param("ssss",$q_id,$cu,$_POST['fed'],$re);
      $stmt->execute();
      CloseCon($conn);
    }
    ?>




</body>
</html>