<?php
    session_start();
    // Check if the user is logged in, if not then redirect him to login page
        if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
        header("location: login.php");
        exit;}

    include 'db_connection.php';

    $conn = OpenCon();
    
    $cust = $_SESSION['id'];
    $name = null;
    $address = null;
    $points = null;
    $mob = null;
    $user = $_SESSION['username'];
    $adhar = null;
    $email = null;
    $details = $conn->query("SELECT customer.Email_id,customer.points,customer_person.Name,customer_person.Address,customer.Adhar_id from customer INNER JOIN customer_person ON customer.Adhar_id = customer_person.Adhar_id where Cust_id='$cust'");
    
    while($X = mysqli_fetch_assoc($details)){
        $adhar = $X['Adhar_id'];
        $address = $X['Address'];
        $points = $X['points'];
        $email = $X['Email_id'];
        $name = $X['Name'];
    }

    $mobile = $conn->query("SELECT Mobile_no from customer_mobile where Adhar_id='$adhar'");
    while($X = mysqli_fetch_assoc($mobile)){
        $mob = $X['Mobile_no'];
    }
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Account</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; }
        .wrapper{ width: 700px; padding: 25px; }

        h2{
            text-align: center;
            margin-top: -25px;
            padding-bottom: 25px;
            font-family: Impact, Charcoal, sans-serif;
            font-size: 250%;
        }

        body{
             background-image: url(images/login_page.jpg);
            background-repeat: no-repeat;
            background-size: cover;
            font-size: 12pt;
            }
        
        label{
            color: #d1bd48;
        }

        .wrapper{
            margin-top: 40px;
            border-radius: 5px;
            background-color: #000000;
            color: #FFFFFF;
            position: absolute;
            left: 450px;
            }

        input[type='button']{
            margin-left: 280px;
        }

        .already{
            text-align: center;
        }

        #firstp{
            text-align: center;
        }

        textarea
        {
            border: none;
            border-bottom: 1px solid #fff;
            background: transparent;
            outline: none;
            height: 30px;
            color: #fff;
            font-size: 12px;
        }

    </style>
</head>
<body>
    <div class="wrapper">
        <h2>Account details</h2>

            <div class="form-group ">
                <label>Customer_Id</label>
                <textarea name="username" rows="1" class="form-control" value = "cssc" ><?php echo $cust; ?></textarea>
                <span class="help-block"></span>
            </div>

            <div class="form-group">
                <label>Username</label>
                <textarea name="username" rows="1" cols="10" class="form-control" ><?php echo $user; ?></textarea>
            </div> 

            <div class="form-group ">
                <label>Name</label>
                <textarea name="username" rows="1" class="form-control" ><?php echo $name; ?></textarea>
                <span class="help-block"></span>
            </div>

            <div class="form-group ">
                <label>Email_Id</label>
                <textarea name="username" rows="1"  class="form-control" ><?php echo $email; ?></textarea>
                <span class="help-block"></span>
            </div>

            <div class="form-group">
                <label>Mobile Number</label>
                <textarea name="username" rows="1" class="form-control" ><?php echo $mob; ?></textarea>
            </div>
            
            <div class="form-group">
                <label>Address</label>
                <textarea name="username" rows="1" class="form-control" ><?php echo $address; ?></textarea>
                <span class="help-block"></span>
            </div>

            <div class="form-group">
                <label>Points</label>
                <textarea name="username" rows="1" class="form-control" ><?php echo $points; ?></textarea>
                <span class="help-block"></span>
            </div>


            <div class="form-group">
                <input type="button" class="btn btn-primary" value="HOME" onclick="window.location.href='homepage.php';">
            </div>
    </div>    
</body>
</html>