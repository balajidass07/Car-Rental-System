<?php
    session_start();
    // Check if the user is logged in, if not then redirect him to login page
        if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
        header("location: login.php");
        exit;}
?>


<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
* {
  box-sizing: border-box;
}

body{
  background-image: url("images/feedimg.jpg");
  background-repeat: no-repeat;
  background-size:cover;
}

form
{
margin-left: 800px;
width: 100px;
align:right;
}

header img{
  background-color: #FFFFFF;
  border-radius: 5px;
  width: 500px;
  height: 150px;
  margin-left: 700px;
}

#comments{
  background-color: #FFFFFF;
  border-radius: 5px;
  width: 50px;
  height: 100px;
  margin-top:100px;
  margin-left: 700px;
}

textarea {
  width: 450%;
  padding: 12px;
  border: 2px solid #DDA0DD;
  background-color:#D8BFD8;
  border-radius: 10px;
  resize: vertical;
  margin-left:-60px;
  margin-top:30px;
}

label {
  padding: 12px 12px 12px 0;
  display: inline-block;
}


.button1{
	padding-left: 5px;
	padding-top: 5px;
	padding-right: 5px;
	padding-bottom: 5px;
 	border-radius: 10px;
  	background-color: #DA70D6;
  	border: none;
 	color: #000000;
	margin-left:97px;
	margin-top:10px;
	width:100px;
	font-family: "Arial Black", Gadget, sans-serif;
  	text-align: center;
  	font-size: 20px;
 
}

.button1:hover{
	background-color:#000000;
	color: #ffffff;
	
}


.button2{
	padding-left: 0px;
	padding-right: 0px;
 	border-radius: 10px;
  	background-color: #9370DB;
  	border: none;
 	color: #000000;
	margin-left:0px;
	margin-top:-780px;
	width:130px;
	font-family: "Arial Black", Gadget, sans-serif;
  	text-align: center;
  	font-size: 25px;
 
}

.button2:hover{
	background-color:#DA70D6;
	color: #000000;
	font-size: 30px;
}


}
</style>


<!--Database Connection-->
  <?php
    include 'db_connection.php';
    ?>


</head>
<header>
<img src="images/feedhd.jpg">
</header>


<body>

<form method="post" target="_self">

  <textarea name="feed" rows="10" cols="10">FEEDBACK HERE..</textarea>

  <input type="submit" name="go" class="button1" value="Submit">

</form>

<button class="button2" onclick="window.location.href='homepage.php';" style="vertical-align:middle"><span>Home </span></button> 

<!--INSERT IN BOOKING-->
    <?php
      $conn = OpenCon();
    if(isset($_POST['go'])){
      $sql = "INSERT INTO feedback VALUES(?,?,?)";
      $var1 = $_POST['feed'];

      $cu = $_SESSION["id"];
      
      //Feedback_id
      $f_id = null;
      $row = $conn->query("SELECT Feedback_id FROM feedback ORDER BY Feedback_id DESC LIMIT 1; ");
      while ($X = mysqli_fetch_assoc($row)){
        $f_id = $X['Feedback_id'];
      }
      if($f_id == null){
        $f_id ='F01';
      }
      else{
      $fid_num = (int) filter_var($f_id, FILTER_SANITIZE_NUMBER_INT);
      $fid_num = $fid_num+1;
      if($fid_num<10){
      $f_id = 'F0'.$fid_num;
      }
      else{
        $f_id = 'F'.$fid_num;
      }}

      $stmt = mysqli_prepare($conn,$sql);
      $stmt->bind_param("sss",$f_id,$cu,$_POST['feed']);
      $stmt->execute();
      CloseCon($conn);
    }
    ?>




</body>
</html>