<?php
    include 'db_connection.php';

    session_start();
    // Check if the user is logged in, if not then redirect him to login page
        if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
        header("location: login.php");
        exit;}
        
        //Checking if Cars are available
        $conn = OpenCon();
        $cars_list = $conn->query("SELECT Car_name from car where availability=0");
        $val = 0;
        if(mysqli_num_rows($cars_list)==0){
            $val = 1;
        }
        CloseCon($conn);
?>
    
    <html>
    <head>
        <meta charset="utf-8">
        <title>Home page</title>
        <link rel="stylesheet" type="text/css" href="css/homepage.css">

        <script type="text/javascript">
            function booking(){
                var ct = "<?php echo $val ?>";
                if(ct==1){
                  alert("Sorry! No cars are available right now");
                }
                else{
                  window.location.href = "book.php";
                }
            }

        </script>

    </head>

    <body>
        <img src="images/logo.png" alt="Preview not avaliable" id="logo">
        <header>
            <nav>
                <a href="" id="book">My Account</a>
                <a href="feedback.php" id="feedback">Feedback</a>
                <a href="query.php" id="query">Query</a>
                <a href="" id="history">History</a>
                <a href="logout.php" id="logout">LogOut</a>
            </nav>
        </header>

        <div>
       <section class="left">
           <h1 id="h1">Welcome to our </h1>
           <h1 id="h2">Car Rental System</h1>
           <p id="p1">A well developed Car rental company with all varieties of cars.</p>
           <br><br>
           <button class="button" onclick=booking();><span>BOOK NOW</span></button>

           <p id="p2">Credit cards accepted.</p>

       </section> 
       </div>
       
    </body>

</html>