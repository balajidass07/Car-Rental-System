<?php
    include 'db_connection.php';
    $s = session_name ("loggedin1");
    session_start();
    // Check if the user is logged in, if not then redirect him to login page
        if(!isset($_SESSION["loggedin1"]) || $_SESSION["loggedin1"] !== true){
        header("location: Adminlogin.php");
        exit;}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Cars</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/perfect-scrollbar/perfect-scrollbar.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main2.css">
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-table100">
			<div class="wrap-table100">
				<div class="table100">
				<!--<h1 style="text-align:center";>CARS LIST</h1>-->
					<table>
						<thead>
							<tr class="table100-head">
                            <th class="column1">Feedback_Id</th>
<th class="column2"> Customer_Id</th>
<th class="column3"> Adhar_Id</th>
<th class="column4">Customer_name</th>
<th class="column5">Mobile</th>
<th class="column6">Feedback</th>
							</tr>
						</thead>
						<tbody>
						<?php
    $conn = OpenCon();
    $sql = "SELECT feedback.Feedback_id,feedback.cust_ref_id,customer.Adhar_id,feedback.feedback_cust,customer_person.Name,customer_mobile.Mobile_no FROM feedback INNER JOIN customer ON feedback.cust_ref_id = customer.Cust_id INNER JOIN customer_person ON customer.Adhar_id=customer_person.Adhar_id INNER JOIN customer_mobile ON customer.Adhar_id=customer_mobile.Adhar_id;";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            echo "<tr><td class=column1>" . $row["Feedback_id"]. "</td><td class=column2>" . $row["cust_ref_id"] . "</td><td class=column3>" . $row["Adhar_id"] . "</td><td class=column4>". $row["Name"]. "</td><td class=column5>" . $row["Mobile_no"]. "</td><td class=column6>" . $row["feedback_cust"]. "</td>
            </tr>";}
            echo "</table>";
        }   
        else { echo "0 results"; }
        CloseCon($conn);
?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>


	

<!--===============================================================================================-->	
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>