<?php
    include 'db_connection.php';
    $s = session_name ("loggedin1");
    session_start();
    // Check if the user is logged in, if not then redirect him to login page
        if(!isset($_SESSION["loggedin1"]) || $_SESSION["loggedin1"] !== true){
        header("location: Adminlogin.php");
        exit;}

        $conn = OpenCon();
        $feedbacks_list = $conn->query("SELECT * from feedback");
        $val = 0;
        if(mysqli_num_rows($feedbacks_list)==0){
            $val = 1;
        }

        $query_list = $conn->query("SELECT * from query where reply_admin='Not yet answered'");
        $val1 = 0;
        if(mysqli_num_rows($query_list)==0){
            $val1 = 1;
        }

        CloseCon($conn);
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>ADMIN HOME</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.min.css">
    
    <script type="text/javascript">
            function feedbacks(){
                var ct = "<?php echo $val ?>";
                if(ct==1){
                  alert("There are no feedbacks to been viewed!!");
                }
                else{
                  window.location.href = "admin_feedback.php";
                }
            }

            function queries(){
                var ct = "<?php echo $val1 ?>";
                if(ct==1){
                  alert("No queries are left to be answered !!");
                }
                else{
                  window.location.href = "admin_q.php";
                }
            }

        </script>

</head>

<body style=" background: rgb(236,160,248);background-image: url(homepage4.jpg);background-size: cover;background-repeat: no-repeat;">
    <nav class="navbar navbar-light navbar-expand-md">
        <div class="container-fluid"><h1 style="text-align: center; margin-left: 650px; font-family: Arial, Helvetica, sans-serif; color: red;font-weight: bold;">Admin</h1></div>
    </nav>
    <div class="container">
        <div class="row">
            <div class="col offset-lg-0" style="height: 470px;text-align: center;">
                <div class="row">
                    <div class="col" style="height: 150px;"><a class="btn btn-primary" role="button" style="width: 130px;" href="viewcar2.php">View Cars</a></div>
                </div>
                <div class="row">
                    <div class="col" style="width: 100px;height: 170px;"><a class="btn btn-primary" role="button" style="text-align: center;width: 130px;" href="cardelete.php">Delete Car</a></div>
                </div>
                <div class="row">
                    <div class="col"><a class="btn btn-primary" role="button" style="width: 130px;" href="caradd.php">Add Car</a></div>
                </div>
            </div>
            <div class="col offset-lg-0" style="height: 470px;text-align: center;">
                <div class="row">
                    <div class="col" style="height: 150px;"><a class="btn btn-primary" role="button" style="width: 130px;" href="viewdriver2.php">View Drivers</a></div>
                </div>
                <div class="row">
                    <div class="col" style="width: 100px;height: 170px;"><a class="btn btn-primary" role="button" style="text-align: center;width: 130px;" href="deletedriver.php">Delete Driver</a></div>
                </div>
                <div class="row">
                    <div class="col"><a class="btn btn-primary" role="button" style="width: 130px;" href="driveradd.php">Add Driver</a></div>
                </div>
            </div>
        </div>
        <div class="row" style="height: 170px;">
            <div class="col" style="text-align: center;" ><button class="btn btn-primary" type="button" onclick=window.location.href="payment1.php">Proceed Payment</button></div>
            <div class="col" style="text-align: center;"><button class="btn btn-primary" type="button" onclick=queries();>Answer Queries</button></div>
        </div>
        <div class="row" style="height: 170px;">
        <div class="col" style="text-align: center;width: 100px;"><button class="btn btn-primary" type="button"  onclick=feedbacks();>View Feedbacks</button></div>            
        <div class="col" style="text-align: center;"><button class="btn btn-primary" type="button" onclick=window.location.href="logout1.php">Logout</button></div>
        </div>
    </div>

    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
</body>

</html>