<?php
    include 'db_connection.php';
    $s = session_name ("loggedin1");
    session_start();
    // Check if the user is logged in, if not then redirect him to login page
        if(!isset($_SESSION["loggedin1"]) || $_SESSION["loggedin1"] !== true){
        header("location: Adminlogin.php");
        exit;}
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>drivercreate</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body style="background-color:#E6E6FA;"><nav class="navbar navbar-light navbar-expand-md">
        <div class="container-fluid"><a class="navbar-brand" href="#">ADD DRIVER</a></div>
    </nav>
    <form data-bss-recipient="ed303353e0b20b3026567d0fe0c6a906" method="post" target="_self">
        <div class="form-group">
            <div class="form-row" style="height: 50px;">
                <div class="col"><input class="border rounded-0 border-dark form-control" type="text" placeholder="Driver ID" required="" name="driver_id"></div>
            </div>
            <div class="form-row" style="height: 50px;">
                <div class="col"><input class="border rounded-0 border-dark form-control" type="text" placeholder="Driver Name" required="" name="driver_name"></div>
            </div>
            <div class="form-row" style="text-align: center;height: 50px;">
                <div class="col" style="text-align: center;"><input class="border rounded-0 border-dark form-control" type="text" placeholder="Adhar ID" required="" name="adhar_id"></div>
            </div>
            <div class="form-row" style="text-align: center;height: 50px;">
                <div class="col" style="text-align: center;"><input class="border rounded-0 border-dark form-control" type="number" placeholder="Experience " required="" name="driver_exp"></div>
            </div>
            <div class="form-row" style="height: 50px;">
                <div class="col"><input class="border rounded-0 border-dark form-control" type="number" placeholder="Driver Mobile" required="" name="driver_mobile"></div>
            </div>
            <div class="form-row" style="height: 50px;">
                <div class="col"><input class="border rounded-0 border-dark form-control" type="number" placeholder="Rating" required="" name="driver_rate"></div>
            </div>
            <div class="form-row" style="text-align: center;height: 50px;">
                <div class="col" style="text-align: center;"><input class="border rounded-0 border-dark form-control" type="text" placeholder="Address" required="" name="driver_address"></div>
            </div>
            <div class="form-row" style="height: 50px;">
                <div class="col text-center"><button name="adddriver" class="btn btn-primary" type="submit" style="width: 150px;height: 40px;">ADD DRIVER</button></div>
            </div>

        </div>

        <?php
            //DRIVER ADD
            $conn = OpenCon();

            if(isset($_POST['adddriver'])){
            
            //Insert into driver table
            $sql = "INSERT INTO driver(Driver_id,Adhar_id,experience,rating) VALUES(?,?,?,?)";
            $stmt = mysqli_prepare($conn,$sql);
            $stmt->bind_param("ssss",$_POST['driver_id'],$_POST['adhar_id'],$_POST['driver_exp'],$_POST['driver_rate']);

            if(mysqli_stmt_execute($stmt)){
                
                //Insert into driver_person table
                $sql1 = "INSERT INTO driver_person VALUES(?,?,?)";
                $stmt1 = mysqli_prepare($conn,$sql1);
                $stmt1->bind_param("sss",$_POST['adhar_id'],$_POST['driver_name'],$_POST['driver_address']);
                $stmt1->execute();

                //Insert into driver_mobile table
                $sql2 = "INSERT INTO driver_mobile VALUES(?,?)";
                $stmt2 = mysqli_prepare($conn,$sql2);
                $stmt2->bind_param("ss",$_POST['adhar_id'],$_POST['driver_mobile']);
                $stmt2->execute();

                echo '<script type="text/JavaScript">  
                alert("Driver added successfully !! "); 
                </script>' ; 
            }
            
            Closecon($conn);
            }
        ?>
    </form>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
</body>

</html>