<?php
    include 'db_connection.php';
    $s = session_name ("loggedin1");
    session_start();
    // Check if the user is logged in, if not then redirect him to login page
        if(!isset($_SESSION["loggedin1"]) || $_SESSION["loggedin1"] !== true){
        header("location: Adminlogin.php");
        exit;}
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Payment</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
</head>

<body style="background: rgb(180,175,175);">
    <nav class="navbar navbar-light navbar-expand-md">
        <div class="container-fluid"><a class="navbar-brand" href="#">Payment Menu</a></div>
    </nav>
    <form data-bss-recipient="ed303353e0b20b3026567d0fe0c6a906" method="post" target="_self">
        <div class="form-group">
            <div class="form-row" style="height: 50px;">
                <div class="col"><input class="border rounded-0 border-dark form-control" type="text" placeholder="Booking ID" required="" name="book_id"></div>
            </div>
            <div class="form-row" style="height: 50px;">
                <div class="col"><input class="border rounded-0 border-dark form-control" type="text" placeholder="km on run" required="" name="km"></div>
            </div>
            <div class="form-row" style="height: 50px;">
                <div class="col text-center"><button name="pay" class="btn btn-primary" type="submit"  style="width: 100px;height: 40px;">Proceed</button></div>
            </div>
            <div class="form-row" style="height: 50px;">
                <div class="col text-center"><input name="apply" class="btn btn-primary" type="checkbox" style="width: 30px;height: 30px;">Applied discount</button></div>
            </div>
        </div>

    <?php

        if(isset($_POST['pay'])){
            
            $conn = OpenCon();
            //Payment ID
            $p_id = null;
            $row = $conn->query("SELECT Payment_id FROM payment ORDER BY Payment_id DESC LIMIT 1;");
            while ($X = mysqli_fetch_assoc($row)){
                $p_id = $X['Payment_id'];
            }
            if($p_id == null){
                $p_id ='P01';
            }
            else{
                $pid_num = (int) filter_var($p_id, FILTER_SANITIZE_NUMBER_INT);
                $pid_num = $pid_num+1;
            if($pid_num<10){
                $p_id = 'P0'.$pid_num;
            }
            else {
                $p_id = 'P'.$pid_num;
            }}

            //Booking_ref_id
            $b_id = $_POST['book_id'];
            $c_id = null;
            $v_id = null;
            $result = $conn->query("SELECT cust_ref_id from booking WHERE Booking_id='$b_id'");
            while ($X = mysqli_fetch_assoc($result)){
              $c_id = $X['cust_ref_id'];
            }
            

            //Total
            $total = 0;
                //Calculating Car Amount
            $result = $conn->query("SELECT car_ref_id from booking WHERE Booking_id='$b_id'");
            while ($X = mysqli_fetch_assoc($result)){
              $v_id = $X['car_ref_id'];
            }
            $amount = 0;
            $result = $conn->query("SELECT rate_per_km from car WHERE Car_id='$v_id'");
            while ($X = mysqli_fetch_assoc($result)){
              $amount = $X['rate_per_km'];
            }
            $total = $total+($amount*$_POST['km']);

                //Calculating for driver
            $d_id = null;
            $result = $conn->query("SELECT driver_ref_id from booking WHERE Booking_id='$b_id'");
            while ($X = mysqli_fetch_assoc($result)){
                $d_id = $X['driver_ref_id'];
              }
            if($d_id!=null){
                $total = $total+(5*$_POST['km']);
            }
            
            //Discount(from points)
            $discount = 0;
            $result = $conn->query("SELECT points from Customer WHERE Cust_id='$c_id'");
            while ($X = mysqli_fetch_assoc($result)){
              $discount = $X['points'];
            }
            
            $balance = 0;
            $balance = $total-$discount;
            
            //discount
            $discount_applied = false;
            if(isset($_POST['apply'])){
                $discount_applied = true;
            }

            //Insert into payment table
            $sql = "INSERT INTO payment VALUES(?,?,?,?,?,?,?)";
            $stmt = mysqli_prepare($conn,$sql);
            $stmt->bind_param("sssssss",$p_id,$c_id,$b_id,$total,$discount,$balance,$discount_applied);
            if(mysqli_stmt_execute($stmt)){
            
                //Update availability of car 
                $sql4 = "UPDATE car SET availability=0 where Car_id='$v_id'";
                $stmt1 = mysqli_prepare($conn,$sql4);
                $stmt1->execute();

                //Update availability of driver 
                if($d_id != null){
                    $sql4 = "UPDATE driver SET availability=0 where Driver_id='$d_id'";
                    $stmt2 = mysqli_prepare($conn,$sql4);
                    $stmt2->execute();
                }

                header("location: payment2.php");
            }
            else{
                echo $c_id;
                echo '<script type="text/JavaScript">  
                alert("No such Booking ID :("); 
                </script>' ; 
            }
         CloseCon($conn);
        }
    ?>
    </form>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>