<?php
    include 'db_connection.php';
    $s = session_name ("loggedin1");
    session_start();
    // Check if the user is logged in, if not then redirect him to login page
        if(!isset($_SESSION["loggedin1"]) || $_SESSION["loggedin1"] !== true){
        header("location: Adminlogin.php");
        exit;}
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>driverdelete</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body style="background-color:#E6E6FA;"><nav class="navbar navbar-light navbar-expand-md">
        <div class="container-fluid"><a class="navbar-brand" href="#">DELETE DRIVER</a></div>
    </nav>
    <form data-bss-recipient="ed303353e0b20b3026567d0fe0c6a906" method="POST" target="_self">
        <div class="form-group">
            <div class="form-row" style="height: 50px;">
                <div class="col"><input class="border rounded-0 border-dark form-control" type="text" placeholder="Driver ID" required="" name="driver_id"></div>
            </div>
            <div class="form-row" style="height: 50px;">
                <div class="col text-center"><button name="deletedriver" class="btn btn-primary" type="submit" style="width: 140px;height: 40px;">DELETE&nbsp;DRIVER</button></div>
            </div>
        </div>

        <?php

            $conn = OpenCon();
            if(isset($_POST['deletedriver'])){

                //Delete from Driver_mobile 
                $var = $_POST['driver_id'];
                $sql1 = "DELETE FROM driver_mobile where Adhar_id=(SELECT Adhar_id from driver where driver_id='$var')";
                $stmt1 = mysqli_prepare($conn,$sql1);
                $stmt1->execute();
                         
                //Delete from driver_person
                $sql2 = "DELETE FROM driver_person where Adhar_id=(SELECT Adhar_id from driver where driver_id='$var')";
                $stmt2 = mysqli_prepare($conn,$sql2);
                $stmt2->execute();

                //Delete from
                $sql = "DELETE FROM driver where driver_id = ?";
                $stmt = mysqli_prepare($conn,$sql);
                $stmt->bind_param("s",$_POST['driver_id']);
                if(mysqli_stmt_execute($stmt)){
                echo '<script type="text/JavaScript">  
                alert("Driver Removed !! "); 
                </script>' ; 
                }
                
                CloseCon($conn);
            }
        ?>
    </form>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
</body>

</html>